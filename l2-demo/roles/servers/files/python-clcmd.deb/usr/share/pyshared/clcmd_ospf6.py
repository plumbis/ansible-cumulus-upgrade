#!/usr/bin/env python

from clcmd_handler import ClCmdHandler

class ClCmdOspf6(ClCmdHandler):

    def whatis(self):
        return "show / manipulate OSPFv3 routing"

    def description(self, prog):
        return "%s is a bash command line wrapper around Quagga's integrated " \
               "user interface shell called vtysh, wrapping commands relevant " \
               "to OSPFv3." % prog

    def see_also(self):
        return "http://www.nongnu.org/quagga/docs/docs-info.html#OSPFv3"

    def execute(self, prog, args):
        if not args:
            return None, self.usage(prog, args)
        out, err = self.run("grep '[ \t]*ospf6d=yes' /etc/quagga/daemons")
        if not out.strip():
            return None, "ospf6d is not running. Please start ospf6d\n"

        return super(ClCmdOspf6, self).execute(prog, args)

    def rosetta(self):

        VTYSH = "/usr/bin/vtysh -c "

        base_rosetta = [
            ("version", VTYSH + "'show version'", "show zebra version"),
            ("version show", VTYSH + "'show version'", "show zebra version"),

            ("spf",
                VTYSH + "'show ipv6 ospf6 /0 tree'",
                "show SPF tree"),
            ("spf show",
                VTYSH + "'show ipv6 ospf6 /0 tree'",
                "show SPF tree"),
            ("spf show area [A.B.C.D]",
                VTYSH + "'show ipv6 ospf6 /2 /3 /0 tree'",
                "show SPF tree for area"),

            ("border-routers",
                VTYSH + "'show ipv6 ospf6 /0'",
                ""),
            ("border-routers show",
                VTYSH + "'show ipv6 ospf6 /0'",
                ""),
            ("border-routers show [A.B.C.D]",
                VTYSH + "'show ipv6 ospf6 /0 /2'",
                ""),
            ("border-routers show detail",
                VTYSH + "'show ipv6 ospf6 /0 /2'",
                ""),

            ("interface",
                VTYSH + "'show ipv6 ospf6 interface'",
                "show OSPFv3 interfaces"),
            ("interface show",
                VTYSH + "'show ipv6 ospf6 interface'",
                "show OSPFv3 interfaces"),
            ("interface show [INTERFACE]",
                VTYSH + "'show ipv6 ospf6 interface /1'",
                "show OSPFv3 interface"),

            ("linkstate",
                VTYSH + "'show ipv6 ospf6 linkstate'",
                "show OSPFv3 linkstate"),
            ("linkstate show",
                VTYSH + "'show ipv6 ospf6 linkstate'",
                "show OSPFv3 linkstate"),
            ("linkstate show detail",
                VTYSH + "'show ipv6 ospf6 linkstate /2'",
                "show OSPFv3 linkstate details"),
            ("linkstate show network [A.B.C.D] linkid [A.B.C.D]",
             VTYSH + "'show ipv6 ospf6 linkstate /2 /3 /5'",
             "show network LSA of specified router and linkid"),
            ("linkstate show router [A.B.C.D]",
             VTYSH + "'show ipv6 ospf6 linkstate /2 /3'",
             "show LSA of specified router"),
            
            ("neighbor",
                VTYSH + "'show ipv6 ospf6 neighbor'",
                "show OSPFv3 neighbors"),
            ("neighbor show",
                VTYSH + "'show ipv6 ospf6 neighbor'",
                "show OSPFv3 neighbors"),
            ("neighbor show detail",
                VTYSH + "'show ipv6 ospf6 neighbor /2'",
                "show OSPFv3 neighbors' details"),
            ("neighbor show drchoice",
                VTYSH + "'show ipv6 ospf6 neighbor /2'",
                "show OSPFv3 neighbors' (backup) DR choice"),

            ("route",
                VTYSH + "'show ipv6 ospf6 route'",
                "show OSPFv3 routes"),
            ("route show",
                VTYSH + "'show ipv6 ospf6 route'",
                "show OSPFv3 routes"),
            ("route show detail",
                VTYSH + "'show ipv6 ospf6 route /2'",
                "show details of OSPFv3 routes"),
            ("route show summary",
                VTYSH + "'show ipv6 ospf6 route /2'",
                "show summary of OSPFv3 routes"),
            ("route show [X:X::X:X/M]",
                VTYSH + "'show ipv6 ospf6 route /2'",
                "show OSPFv3 route"),
            ("route show [X:X::X:X/M] longer",
                VTYSH + "'show ipv6 ospf6 route /2 /3'",
                "show OSPFv3 routes longer than prefix"),
            ("route show [X:X::X:X/M] longer detail",
                VTYSH + "'show ipv6 ospf6 route /2 /3 /4'",
                "show details of OSPFv3 routes longer than prefix"),
            ("route show [X:X::X:X/M] match",
                VTYSH + "'show ipv6 ospf6 route /2 /3'",
                "show OSPFv3 routes that match prefix"),
            ("route show [X:X::X:X/M] match detail",
                VTYSH + "'show ipv6 ospf6 route /2 /3 /4'",
                "show details of OSPFv3 routes that match prefix"),
            ("route show lsa-type [LSA-TYPE]",
                VTYSH + "'show ipv6 ospf6 route /3'",
                "show routes matching LSA-TYPE := { %s }" % \
                    ' | '.join(self.routes_by_lsa_type(None))),
            ("route show lsa-type [LSA-TYPE] detail",
                VTYSH + "'show ipv6 ospf6 route /3 /4'",
                "show details for routes matching LSA-TYPE := { %s }" % \
                    ' | '.join(self.routes_by_lsa_type(None))),

            ("router",
                VTYSH + "'show ipv6 ospf6'",
                "show router"),
            ("router show",
                VTYSH + "'show ipv6 ospf6'",
                "show router"),
            ("router show redistribute",
                VTYSH + "'show ipv6 ospf6 redistribute'",
                ""),

            ("database",
                VTYSH + "'show ipv6 ospf6 database'",
                "show link state database (lsdb)"),
            ("database show",
                VTYSH + "'show ipv6 ospf6 database'",
                "show link state database (lsdb)"),
            ("database show linkstate-id [A.B.C.D]",
                VTYSH + "'show ipv6 ospf6 database /2 /3'",
                "show link state database (lsdb) for linkstate-id"),
            ("database show adv-router [A.B.C.D]",
                VTYSH + "'show ipv6 ospf6 database /2-'",
                "show link state database (lsdb) for advertising router"),
            ("database show adv-router [A.B.C.D] [option1]",
             VTYSH + "'show ipv6 ospf6 database /2-'",
             "show link state database (lsdb) for advertising router"),
            ("database show [option1]",
             VTYSH + "'show ipv6 ospf6 database /2'", ""),
            ("database show [option1] [option2]",
             VTYSH + "'show ipv6 ospf6 database /2-'", ""),
            ("database show [option1] [option2] [option3]",
             VTYSH + "'show ipv6 ospf6 database /2-'", ""),
            ("database show [option1] adv-router [A.B.C.D] [dump|detail|internal]",
             VTYSH + "'show ipv6 ospf6 database /2-'", ""),

            ("debug", "'show debugging ospf6'", ""),
            ("debug show", "'show debugging ospf6'", ""),
            ("debug set [OBJECT]", VTYSH + "'debug ospf6 /2'", ""),
            ("debug clear [OBJECT]", VTYSH + "'no debug ospf6 /2'", ""),
            ("debug set abr", VTYSH + "'debug ospf6 /2'", ""),
            ("debug clear abr", VTYSH + "'debug ospf6 /2'", ""),
            ("debug set asbr", VTYSH + "'debug ospf6 /2'", ""),
            ("debug clear abr", VTYSH + "'debug ospf6 /2'", ""),
            ("debug set border-routers", VTYSH + "'debug ospf6 border-routers'", ""),
            ("debug clear border-routers", VTYSH + "'no debug ospf6 border-routers'", ""),
            ("debug set lsa [LSA-TYPE]", VTYSH + "'debug ospf6 /2 /3'", ""),
            ("debug clear lsa [LSA-TYPE]", VTYSH + "'no debug ospf6 /2 /3'", ""),
            ("debug set lsa [LSA-TYPE] originate", VTYSH + "'debug ospf6 /2 /3 /4'", ""),
            ("debug clear lsa [LSA-TYPE] originate", VTYSH + "'no debug ospf6 /2 /3 /4'", ""),
            ("debug set lsa [LSA-TYPE] examine", VTYSH + "'debug ospf6 /2 /3 /4'", ""),
            ("debug clear lsa [LSA-TYPE] examine", VTYSH + "'no debug ospf6 /2 /3 /4'", ""),
            ("debug set lsa [LSA-TYPE] flooding", VTYSH + "'debug ospf6 /2 /3 /4'", ""),
            ("debug clear lsa [LSA-TYPE] flooding", VTYSH + "'no debug ospf6 /2 /3 /4'", ""),
            ("debug set message [TYPE]", VTYSH + "'debug ospf6 /2 /3'", ""),
            ("debug clear message [TYPE]", VTYSH + "'no debug ospf6 /2 /3'", ""),
            ("debug set message [TYPE] send", VTYSH + "'debug ospf6 /2 /3'", ""),
            ("debug clear message [TYPE] send", VTYSH + "'no debug ospf6 /2 /3'", ""),
            ("debug set message [TYPE] recv", VTYSH + "'debug ospf6 /2 /3'", ""),
            ("debug clear message [TYPE] recv", VTYSH + "'no debug ospf6 /2 /3'", ""),
            ("debug set neighbor state", VTYSH + "'debug ospf6 /2 /3'", ""),
            ("debug clear neighbor state", VTYSH + "'no debug ospf6 /2 /3'", ""),
            ("debug set neighbor event", VTYSH + "'debug ospf6 /2 /3'", ""),
            ("debug clear neighbor event", VTYSH + "'no debug ospf6 /2 /3'", ""),
            ("debug set route [TYPE]", VTYSH + "'debug ospf6 /2 /3'", ""),
            ("debug clear route [TYPE]", VTYSH + "'no debug ospf6 /2 /3'", ""),
            ("debug set spf [TYPE]", VTYSH + "'debug ospf6 /2 /3'", ""),
            ("debug clear spf [TYPE]", VTYSH + "'no debug ospf6 /2 /3'", ""),
            ("debug set zebra all", VTYSH + "'debug ospf6 zebra'", ""),
            ("debug clear zebra all", VTYSH + "'no debug ospf6 zebra'", ""),
            ("debug set zebra [DIR]", VTYSH + "'debug ospf6 zebra /3'", ""),
            ("debug clear zebra [DIR]", VTYSH + "'no debug ospf6 zebra /3'", ""),
            ("debug set all", self.debug_set_all, ""),
            ("debug clear all", self.debug_clear_all, ""),
        ]

        VTYSH_ROUTER = "/usr/bin/vtysh -c 'conf term' -c 'router ospf6' -c "

        router_rosetta = [
            ("area add [A.B.C.D] range [X:X::X:X/M]",
                VTYSH_ROUTER + "'area /2 range /4'",
                "routes within range [X:X::X:X/M] are announced " \
                "summarized from area [A.B.C.D]"),
            ("area add [A.B.C.D] range [X:X::X:X/M] cost <0-16777215>",
                VTYSH_ROUTER + "'area /2 range /4 cost /6'",
                "routes within range [X:X::X:X/M] are advertised " \
                "summarized from area [A.B.C.D] with advertised cost"),
            ("area add [A.B.C.D] range [X:X::X:X/M] not-advertise",
                VTYSH_ROUTER + "'area /2 range /4 not-advertise'",
                "routes within range [X:X::X:X/M] are not advertised " \
                "from area [A.B.C.D] "),
            ("area del [A.B.C.D] range [X:X::X:X/M]",
                VTYSH_ROUTER + "'no area /2 range /4'",
                "routes within range [X:X::X:X/M] are not summarized " \
                "from area [A.B.C.D]"),

            ("area set [A.B.C.D] stub",
                VTYSH_ROUTER + "'area /2 stub'",
                "Make specified area stubby"),
            ("area clear [A.B.C.D] stub",
                VTYSH_ROUTER + "'no area /2 stub'",
                "Make specified area NOT stubby"),
            ("area set [A.B.C.D] stub no-summary",
                VTYSH_ROUTER + "'area /2 stub no-summary'",
                "Make specified area stubby"),
            ("area clear [A.B.C.D] stub no-summary",
                VTYSH_ROUTER + "'no area /2 stub no-summary'",
                "Make specified area normal"),

            ("redistribute add [ROUTES]",
                VTYSH_ROUTER + "'redistribute /2'",
                ""),
            ("redistribute del [ROUTES]",
                VTYSH_ROUTER + "'no redistribute /2'",
                ""),

            ("router-id set [A.B.C.D]",
                VTYSH_ROUTER + "'router-id /2'",
                "set router ID"),

            ("log-adjacency-changes set",
             VTYSH_ROUTER + "'log-adjacency-changes'",
             "configures ospf6d to log changes in adjacency. With " \
             "the optional detail argument, all changes in adjacency " \
             "status are shown. Without detail, only changes to full " \
             "or regressions are shown."),
            ("log-adjacency-changes set detail",
             VTYSH_ROUTER + "'log-adjacency-changes detail'",
             "configures ospf6d to log changes in adjacency. With " \
             "the optional detail argument, all changes in adjacency " \
             "status are shown. Without detail, only changes to full " \
             "or regressions are shown."),
            ("log-adjacency-changes clear", VTYSH_ROUTER + "'no log-adjacency-changes'", ""),

            ("stub-router set administrative",
             VTYSH_ROUTER + "'stub-router administrative'",
             "Make router a stub router. Allows for graceful removal from network"),
            ("stub-router clear administrative",
             VTYSH_ROUTER + "'no stub-router administrative'",
             "Make router a normal OSPFv3 router, not a stub router"),

            ("timer add throttle spf <0-600000> <0-600000> <0-600000>",
                VTYSH_ROUTER + "' /0 /2 /3 /4 /5 /6'",
                ""),
            ("timer del throttle spf",
                VTYSH_ROUTER + "'no /0 /2 /3'",
                ""),
        ]

        VTYSH_INTERFACE = "/usr/bin/vtysh -c 'conf term' -c "

        interface_rosetta = [

            ("interface set [INTERFACE] network point-to-point",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface network type to point-to-point"),
            ("interface set [INTERFACE] network broadcast",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface network type to broadcast"),

            ("interface set [INTERFACE] passive",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3'",
                "enable passive mode on interface"),
            ("interface clear [INTERFACE] passive",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3'",
                "disable passive mode on interface"),

            ("interface set [INTERFACE] area [A.B.C.D]",
                VTYSH_ROUTER + "' /0 /2 /3 /4'",
                "add interface to area"),
            ("interface clear [INTERFACE] area [A.B.C.D]",
                VTYSH_ROUTER + "'no /0 /2 /3 /4'",
                "add interface to area"),

            ("interface set [INTERFACE] cost <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface cost"),
            ("interface clear [INTERFACE] cost <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface cost"),

            ("interface set [INTERFACE] dead-interval <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface dead-interval"),

            ("interface set [INTERFACE] hello-interval <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface hello-interval"),

            ("interface set [INTERFACE] mtu <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 ifmtu /4'",
                "set OSPFv3 interface mtu"),
            ("interface clear [INTERFACE] mtu",
                VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 ospf6 ifmtu'",
                "clear OSPFv3 interface mtu"),

            ("interface set [INTERFACE] instance-id <0-255>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface instance-id"),

            ("interface set [INTERFACE] mtu-ignore",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3'",
                "ignore MTU mismatch on interface"),
            ("interface clear [INTERFACE] mtu-ignore",
                VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 ospf6 /3'",
                "ignore MTU mismatch on interface"),

            ("interface set [INTERFACE] priority <0-255>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface router priority"),

            ("interface set [INTERFACE] retransmit-interval <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface retransmit interval"),

            ("interface clear [INTERFACE] retransmit-interval <1-3600>",
                VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface retransmit-interval"),

            ("interface set [INTERFACE] transmit-delay <1-65535>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 /3 /4'",
                "set OSPFv3 interface transmit delay"),

            ("interface clear [INTERFACE] transmit-delay <1-3600>",
                VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 ospf6 /3 /4'",
                "reset OSPFv3 interface transmit delay to default"),

            ("interface set [INTERFACE] bfd",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 bfd'",
                "set OSPFv3 interface BFD"),

            ("interface set [INTERFACE] bfd detect-multiplier <2-255> min-rx <50-60000> min-tx <50-60000>",
                VTYSH_INTERFACE + "'interface /2' -c 'ipv6 ospf6 bfd /5 /7 /9'",
                "set OSPFv3 interface BFD"),

            ("interface clear [INTERFACE] bfd",
                VTYSH_INTERFACE + "'interface /2' -c 'no ipv6 ospf6 bfd'",
                "reset OSPFv3 interface BFD"),
        ]

        return ClCmdHandler.rosetta(self) + base_rosetta + router_rosetta + interface_rosetta

    def completers(self):
       ospf6_completers = {
           "interface set": self.interfaces,
           "interface clear": self.interfaces,
           "interface show": self.interfaces,
           "spf show area": self.areas,
           "route show": self.routes,
           "route show lsa-type": self.routes_by_lsa_type,
           "area add": self.areas,
           "area del": self.areas,
           "redistribute add": self.router_redistribute,
           "redistribute del": self.router_redistribute,
           "database show adv-router": self.adv_routers,
           "database show adv-router *": self.dbshow_ext_options,
           "database show": self.database_complete,
           "database show *": self.dbshow_options,
           "database show * self-originated": self.dbshow_ext_options,
           "database show * adv-router": self.adv_routers,
           "debug set": self.debug,
           "debug clear": self.debug,
#           "debug set border-routers": self.debug_border_routers,
#           "debug clear border-routers": self.debug_border_routers,
           "debug set lsa": self.debug_lsa,
           "debug clear lsa": self.debug_lsa,
           "debug set message": self.debug_message,
           "debug clear message": self.debug_message,
           "debug set route": self.debug_route,
           "debug clear route": self.debug_route,
           "debug set spf": self.debug_spf,
           "debug clear spf": self.debug_spf,
           "debug set zebra": self.debug_ospf6_zebra,
           "debug clear zebra": self.debug_ospf6_zebra,
       }
       return dict(ClCmdHandler.completers(self).items() + ospf6_completers.items())

    def interfaces(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ipv6 ospf6 interface' | " \
            "/bin/grep '^[^ ]' | /usr/bin/cut -f1 -d ' '", shell=True)
        return out.split()

    def routes(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ipv6 ospf6 route' | " \
            "/usr/bin/cut -f3 -d ' '", shell=True)
        return out.split()

    def routes_by_lsa_type(self, args):
        return ["external-1", "external-2", "inter-area", "intra-area"]

    def areas(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ipv6 ospf6' | " \
            "/bin/grep '^ Area' | /usr/bin/cut -f 3 -d ' '", shell=True)
        return out.split()

    def router_redistribute(self, args):
        return ["kernel", "connected", "static", "ripng", "isis", "bgp", "babel"]

    def adv_routers(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ipv6 ospf6 database router' | " \
            "/usr/bin/awk -F' ' '{print $3}' | /bin/grep '[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*' | /usr/bin/sort | /usr/bin/uniq", shell=True)
        return out.split()

    def database_complete(self, args):
        return (["detail", "dump", "internal", "as-external", "inter-prefix",
                 "intra-prefix", "link", "self-originated", "router",
                 "type-7", "network", "inter-router"])
    
    def dbshow_options(self, args):
        return (["detail", "dump", "self-originated", "internal", "adv-router"])

    def dbshow_ext_options(self, args):
        return (["detail", "dump", "internal"])

    def debug(self, args):
        return ["abr", "asbr", "border-routers", "flooding", "interface",
                "neighbor", "zebra"]

    def debug_border_routers(self, args):
        return ["area-id", "router-id"]

    def debug_lsa(self, args):
        return ["router", "network", "inter-prefix", "inter-router",
                "as-ext", "grp-mbr", "type7", "link", "intra-prefix"]

    def debug_message(self, args):
        return ["unknown", "hello", "dbdesc", "lsreq", "lsupdate", "lsack", "all"]

    def debug_route(self, args):
        return ["table", "intra-area", "inter-area", "memory"]

    def debug_spf(self, args):
        return ["database", "process", "time"]

    def debug_ospf6_zebra(self, args):
        return ["send", "recv"]

    def debug_all(self, args, no):
        for obj in self.debug(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf6 %s'" % (no, obj))
        for lsa_opt in ["", "originate", "examine", "flooding"]:
            for obj in self.debug_lsa(args):
                out, err = self.run("/usr/bin/vtysh -c '%s debug ospf6 lsa %s %s'" % \
                    (no, obj, lsa_opt))
        for msg_opt in ["", "send", "recv"]:
            for obj in self.debug_message(args):
                out, err = self.run("/usr/bin/vtysh -c '%s debug ospf6 message %s %s'" % \
                    (no, obj, msg_opt))
        for obj in self.debug_route(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf6 route %s'" % (no, obj))
        for obj in self.debug_spf(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf6 spf %s'" % (no, obj))
        for obj in self.debug_ospf6_zebra(args):
            out, err = self.run("/usr/bin/vtysh -c '%s debug ospf6 zebra %s'" % (no, obj))
        return ""

    def debug_set_all(self, args):
        return self.debug_all(args, "")

    def debug_clear_all(self, args):
        return self.debug_all(args, "no")

    def debug_show(self, args):
        # there is no ospf6 debug show cmd
        return ""
