#!/usr/bin/env python

from copy import copy
from subprocess import PIPE, Popen
from ipaddr import IPv4Address, IPv4Network, IPv6Address, IPv6Network
from time import strftime
from textwrap import wrap
import re
import shlex

version = "0.01"

class ClCmdHandler(object):

    def __init__(self):
        self.actions = {}
        self.parse_rosetta()
        self.completers = self.completers()
        self.ph_err = None

    def rosetta(self):
        return [
            ("list", self.list, "list commands"),
        ]

    def completers(self):
        return {}

    def _parse_rosetta(self, d, cmd, action):
        if not cmd:
            d["{cr}"] = action
            return
        word = cmd.pop(0)
        d = d.setdefault(word, {})
        if not cmd:
            d["{cr}"] = action
        else:
            self._parse_rosetta(d, cmd, action)

    def parse_rosetta(self):
        for cmd, action, desc in self.rosetta():
            self._parse_rosetta(self.actions, cmd.split(), action)

    def list(self, args):
        listing = ""
        for cmd, action, desc in sorted(self.rosetta()):
            listing += cmd + '\n'
        return listing

    def dump(self, d, level):
        for k, v in d.items():
            if type(v) is dict:
                print " "*level, k
                dump(v, level+4)
            else:
                print " "*level, k, v

    def run(self, cmd, shell=False):
        if not shell:
            cmd=shlex.split(cmd)
        p = Popen(cmd, shell=shell, stdout=PIPE, stderr=PIPE)
        out, err = p.communicate()
        if p.returncode and not err:
            # stupid vtysh print err msg to stdout but returns
            # non-zero return code on err
            err = out; out = ""
        return out, err

    def _placeholder_valid(self, ph, arg):
        # We can pre-validate some place-holder values that
        # match specific patterns
        if ph == "[A.B.C.D]":
            try:
                addr = IPv4Address(arg)
            except:
                self.ph_err = "%s is not a valid IPv4 address\n" % arg
                return False
        elif ph == "[A.B.C.D/M]":
            try:
                addr = IPv4Network(arg)
            except:
                self.ph_err = "%s is not a valid IPv4 network\n" % arg
                return False
        elif ph == "[A.B.C.D|A.B.C.D/M]":
            try:
                addr = IPv4Network(arg)
            except:
                try:
                    addr = IPv4Address(arg)
                except:
                    self.ph_err = "%s is not a valid IPv4 address or network\n" % arg
                    return False
        elif ph == "[X:X::X:X]":
            try:
                addr = IPv6Address(arg)
            except:
                self.ph_err = "%s is not a valid IPv6 address\n" % arg
                return False
        elif ph == "[X:X::X:X/M]":
            try:
                addr = IPv6Network(arg)
            except:
                self.ph_err = "%s is not a valid IPv6 network\n" % arg
                return False
        elif ph == "[X:X::X:X|X:X::X:X/M]":
            try:
                addr = IPv6Network(arg)
            except:
                try:
                    addr = IPv6Address(arg)
                except:
                    self.ph_err = "%s is not a valid IPv6 address or network\n" % arg
                    return False
        elif ph == "[A.B.C.D|X.X::X.X]":
            try:
                addr = IPv4Address(arg)
            except:
                try:
                    addr = IPv6Address(arg)
                except:
                    self.ph_err = "%s is not a valid IPv4/v6 address\n" % arg
                    return False
        elif ph == "[A.B.C.D/M|X.X::X.X/M]":
            try:
                addr = IPv4Network(arg)
            except:
                try:
                    addr = IPv6Network(arg)
                except:
                    self.ph_err = "%s is not a valid IPv4/v6 network\n" % arg
                    return False
        elif ph == "[A.B.C.D|X:X::X:X|peer-group-name]":
            try:
                addr = IPv4Address(arg)
            except:
                try:
                    addr = IPv6Address(arg)
                except:
                    addr = arg
        elif ph == "[A.B.C.D|X:X::X:X|peer-group-name|interface]":
            try:
                addr = IPv4Address(arg)
            except:
                try:
                    addr = IPv6Address(arg)
                except:
                    addr = arg
        elif ph == "[ASN]":
            try:
                if int(arg) >= 1 and int(arg) < 4294967295:
                    pass
                else:
                    raise TypeError("ASN is between 1-4294967295")
            except:
                self.ph_err = "%s is not valid ASN (1-4294967295)\n" % arg
                return False
        elif ph == "[ASN|internal|external]":
            try:
                if arg == "internal" or arg == "external":
                    pass
                elif int(arg) >= 1 and int(arg) < 4294967295:
                    pass
                else:
                    raise TypeError("ASN is between 1-4294967295 or internal or external")
            except:
                self.ph_err = "%s is not valid ASN (1-4294967295) or internal or external\n" % arg
                return False
        elif ph == "[in|out|import|export]":
            try:
                if arg == "in" or arg == "out" or arg == "import" or arg == "export":
                    pass
            except:
                self.ph_err = "%s has to be one of {in, out, import, export}" % arg
                return False

        self.ph_err = None
        return True

    def _placeholder(self, d, arg):
        placeholder = [key for key in d.keys() if '[' in key or '<' in key or '(' in key]
        if len(placeholder) == 1:
            ph = placeholder[0]
            if not self._placeholder_valid(ph, arg):
                return None
            return d[ph]
        return None

    def _complete(self, d, args):
        if not args:
            return d.keys()
        arg = args.pop(0)
        value = d.get(arg)
        if not value:
            ph = self._placeholder(d, arg)
            if ph:
                return self._complete(ph, args)
            return None
        return self._complete(value, args)

    def complete(self, args):
        choices = self._complete(self.actions, copy(args))
        if not choices:
            return '\n'
        if "{cr}" in choices:
            choices.remove("{cr}")

        fn = self.completers.get(' '.join(args))

        # We have commands that need completion that are at the very end
        # of many commands such as "cl-bgp distance set 20 neighbor" or
        # we have commands of the format "cl-bgp x y neighbor show" and
        # we need to complete the neighbor option, so we do this two step
        # backward search
        if not fn and args:
            fn = self.completers.get("* " + args[-1])
        if not fn and args and len(args) >= 2:
            fn = self.completers.get("* " + args[-2])

        if fn:
            more_choices = fn(args)
            if more_choices:
                choices = [key for key in choices if key.find('[') < 0]
                choices.extend(more_choices)
        return ' '.join(choices) + '\n'

    def _substitute(self, action, args):
        arglen = len(args)
        therest = 0
        for i, arg in enumerate(args):
            if therest != 0:
                # This unfortunately renders this substitution to be
                # quagga-specific. There could be other optional end chars
                # that could be considered.
                action = re.sub(r"'[ ]*$", " " + args[i] + "'", action)
            else:
                if " /%u-"%i in action:
                    action = action.replace(" /%u-" % i, " " + args[i])
                    therest = 1
                elif " /%u"%i in action:
                    action = action.replace(" /%u" % i, " " + args[i])
                if " /-%u"%i in action:
                    action = action.replace(" /-%u" % i, " " + args[arglen-i])
                    
        return action

    def _execute(self, d, args):
        if not args:
            action = d.get("{cr}")
            return action
        arg = args.pop(0)
        value = d.get(arg)
        if not value:
            ph = self._placeholder(d, arg)
            if ph:
                return self._execute(ph, args)
            return None
        return self._execute(value, args)

    def execute(self, prog, args):
        action = self._execute(self.actions, copy(args))
        if not action:
            if self.ph_err:
                return None, self.ph_err
            return None, self.usage(prog, args)
        elif type(action) is str:
            action = self._substitute(action, args)
#            print action
            return self.run(action)
        elif callable(action):
            try:
                out = action(args)
                return out, ""
            except Exception as (error):
                return "", str(error) + '\n'
        return None, self.usage(prog, args)

    def objs(self, excluding=[]):
        objs = [cmd for cmd, action, desc in self.rosetta() if cmd]
        objs = set(line.split()[0] for line in objs)
        objs = sorted(objs - set(excluding))
        return objs

    def usage_top(self, prog, objs):
        out = "Usage: %s OBJECT { COMMAND | help }\n" % prog
        out += "       %s list\n" % prog
        out += "       %s version\n" % prog
        out += "\n"
        out += "where OBJECT := {\n"
        for obj in objs:
            if obj == objs[-1]:
                out += "    %s\n" % obj
            else:
                out += "    %s |\n" % obj
        out += "}\n"
        return out

    def usage_sub_details(self, arg):
        return "\n"

    def usage_sub(self, prog, arg):
        out = "Usage: %s %s { COMMAND | help }\n" % (prog, arg)
        out += "\n"
        out += "COMMANDs\n"
        cmds = [(cmd, desc) for cmd, action, desc in self.rosetta() if cmd.split()[0] == arg]
        for cmd, desc in sorted(cmds):
            if len(cmd.split()) > 1:
                out += "\n"
                out += "    %s\n" % ' '.join(cmd.split()[1:])
                for line in wrap(desc, 60):
                    out += "        %s\n" % line
        out += self.usage_sub_details(arg)
        return out

    def usage(self, prog, args):
        objs = self.objs(excluding=["list", "version"])
        if args and args[0] in objs:
            return self.usage_sub(prog, args[0])
        return self.usage_top(prog, objs)

    def whatis(self):
        return "*** override this in sub-class ***"

    def description(self):
        return "*** override this in sub-class ***"

    def see_also(self):
        return "*** override this in sub-class ***"

    def man(self, prog):
        objs = self.objs(excluding=["list", "version"])
        out = '.TH %s 8 "%s" "version %s" "Linux"\n' % (prog.upper(), strftime("%d %b %Y"), version)
        out += ".SH NAME\n"
        out += "%s - %s\n" % (prog, self.whatis())
        out += ".SH SYNOPSIS\n"
        out += ".B %s\n" % prog
        out += "OBJECT { COMMAND | \n"
        out += ".B help \n"
        out += "}\n"
        out += ".sp\n"
        out += ".B %s list\n" % prog
        out += ".sp\n"
        out += ".B %s version\n" % prog
        out += ".sp\n"
        out += "OBJECT := { "
        out += ' | '.join(objs)
        out += " }\n"
        out += ".SH DESCRIPTION\n"
        out += "%s\n" % self.description(prog)
        for obj in objs:
            out += ".SH %s COMMANDS\n" % obj
            cmds = [(cmd, desc) for cmd, action, desc in self.rosetta() if cmd.split()[0] == obj]
            for cmd, desc in sorted(cmds):
                if len(cmd.split()) > 1:
                    out += ".TP\n"
                    out += "%s\n" % ' '.join(cmd.split()[1:])
                    out += "%s\n" % desc 
        out += ".SH SEE ALSO\n"
        out += "%s\n" % self.see_also()
        return out
