#!/usr/bin/env python

import socket
import pickle
import select
import struct
import os

from clcmd_ospf import ClCmdOspf
from clcmd_ospf6 import ClCmdOspf6
from clcmd_ra import ClCmdRa
from clcmd_rctl import ClCmdRctl
from clcmd_bgp import ClCmdBgp

UDS_SOCKET_FILE = "/usr/share/cumulus/clcmd_uds"

class ClCmdServer(socket.socket):

    def __init__(self):

        self.clients = {}
        self.handlers = {}

        try:
            os.unlink(UDS_SOCKET_FILE)
        except OSError:
            if os.path.exists(UDS_SOCKET_FILE):
                raise

        socket.socket.__init__(self, socket.AF_UNIX, socket.SOCK_STREAM)
        self.bind(UDS_SOCKET_FILE)
        self.listen(5)
        
        self.epoll = select.epoll()
        self.epoll.register(self.fileno(), select.EPOLLIN)

    def client_close(self, fileno):

        self.epoll.unregister(fileno)
        self.clients[fileno].close()
        del self.clients[fileno]

    def process(self):

        while True:
    
            events = self.epoll.poll()
    
            for fileno, event in events:
    
                if fileno == self.fileno():
    
                    client, address = self.accept()
                    self.epoll.register(client.fileno(), select.EPOLLIN)
                    self.clients[client.fileno()] = client
    
                elif event & select.EPOLLIN:
    
                    client = self.clients[fileno]

                    try:
                        buf = client.recv(4096)
                        if not buf:   # EOF
                            self.client_close(fileno)
                            continue
                    except socket.error as e:
                        self.client_close(fileno)
    
                    cmd_line = pickle.loads(buf)
    
                    out, err = self.process_cmd_line(cmd_line)
                    output = pickle.dumps((out, err), pickle.HIGHEST_PROTOCOL)

                    try:
                        client.sendall(struct.pack('I', len(output)))
                        client.sendall(output)
                    except socket.error as e:
                        self.client_close(fileno)

    def process_cmd_line(self, cmd_line):

#        print cmd_line
        args = cmd_line.split()
        if len(args) < 2:
            return "", "Empty command line\n"

        client = args.pop(0)
        handler = self.handlers.get(client)
        if not handler:
            return "", "Unknown command handler '%s'\n" % client

        prog = os.path.basename(args.pop(0))

        if "-h" in args or "--help" in args or "help" in args:
            if "-h" in args: args.remove("-h")
            if "--help" in args: args.remove("--help")
            if "help" in args: args.remove("help")
            return handler.usage(prog, args), ""

    
        if args and args[-1] == "?":
            args.pop()
            return handler.complete(args), ""

        return handler.execute(prog, args)

    def register(self, key, handler):
        self.handlers[key] = handler

try:
    s = ClCmdServer()
    s.register("ospf", ClCmdOspf())
    s.register("ospf6", ClCmdOspf6())
    s.register("ra", ClCmdRa())
    s.register("rctl", ClCmdRctl())
    s.register("bgp", ClCmdBgp())
    s.process()

except KeyboardInterrupt:
    pass
