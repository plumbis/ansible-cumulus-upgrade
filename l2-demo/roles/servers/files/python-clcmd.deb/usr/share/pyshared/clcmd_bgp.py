#!/usr/bin/env python

from clcmd_handler import ClCmdHandler

class ClCmdBgp(ClCmdHandler):

    def whatis(self):
        return "show / manipulate BGP routing"

    def description(self, prog):
        return "%s is a bash command line wrapper around Quagga's integrated " \
               "user interface shell called vtysh, wrapping commands relevant " \
               "to BGP." % prog

    def see_also(self):
        return "http://www.nongnu.org/quagga/docs/docs-info.html#BGP"

    def execute(self, prog, args):
        # We add the ASN to the command if this is a command for which vtysh
        # requires an ASN and the user hasn't provided one
        if not args:
            return None, self.usage(prog, args)
        out, err = self.run("grep '[ \t]*bgpd=yes' /etc/quagga/daemons")
        if not out.strip():
            return None, "bgpd is not running. Please start bgpd\n"

        if "as" not in args:
            out, err = self.run("/usr/bin/vtysh -c 'show running-config' | " \
                                "/bin/egrep '^[ \t]*router[ \t]* bgp' | /usr/bin/cut -f3 -d ' '", shell=True)
            # Don't use these keywords in non-config mode commands i.e.
            # commands that're under VTYSH
            mod_cmds = ("add", "del", "set", "clear", "activate", "deactivate", "stop", "start")
            if not out.strip():
                return None, "No valid local ASN found. Please use %s as <ASN> %s\n" % (prog, " ".join(args))
            if args[0] != "debug" and any(s in args for s in mod_cmds):
                args.insert(0, "as")
                args.insert(1, out[:-1])

        return super(ClCmdBgp, self).execute(prog, args)

    # Generate commands for multi-protocol family
    def mp_gen(self, from_str, to_str, help_str):

        if ("\p" in to_str):
            return (from_str.replace("A.B.C.D|X.X::X.X", "A.B.C.D"), to_str.replace("\p", "ipv4"), help_str), \
                   ("-4 " + from_str.replace("A.B.C.D|X.X::X.X", "A.B.C.D"), to_str.replace("\p", "ipv4"), help_str), \
                   ("-6 " + from_str.replace ("A.B.C.D|X.X::X.X", "X.X::X.X"), to_str.replace("\p", "ipv6"), help_str)
        if ("\a" in to_str):
            return (from_str.replace("A.B.C.D|X.X::X.X", "A.B.C.D"), to_str.replace("\a", "ip bgp"), help_str), \
                   ("-4 " + from_str.replace("A.B.C.D|X.X::X.X", "A.B.C.D"), to_str.replace("\a", "ip bgp"), help_str), \
                   ("-6 " + from_str.replace ("A.B.C.D|X.X::X.X", "X.X::X.X"), to_str.replace("\a", "bgp"), help_str)

    def as_gen(self, from_str, to_str, help_str):

        return ("as [ASN] " + from_str, to_str, help_str), \
               (from_str, to_str, help_str)

    def afi_gen(self, from_str, to_str, help_str):

        VTYSH_ROUTER = "/usr/bin/vtysh -c 'conf term' -c 'router bgp /1' -c "
        VTYSH_AFI =  "/usr/bin/vtysh -c 'conf term' -c 'router bgp /1' -c 'address-family /-2 /-1' -c "

        return ("as [ASN] " + from_str + " ipv4 unicast" , VTYSH_AFI + to_str, help_str), \
               ("as [ASN] " + from_str + " ipv4 multicast" , VTYSH_AFI + to_str, help_str), \
               ("as [ASN] " + from_str + " ipv6 unicast", VTYSH_AFI + to_str, help_str), \
               ("as [ASN] " + from_str + " ipv6 multicast" , VTYSH_AFI + to_str, help_str), \
               (from_str + " ipv4 unicast ", VTYSH_AFI + to_str, help_str), \
               (from_str + " ipv4 multicast ", VTYSH_AFI + to_str, help_str), \
               (from_str + " ipv6 unicast ", VTYSH_AFI + to_str, help_str), \
               (from_str + " ipv6 multicast ", VTYSH_AFI + to_str, help_str), \
               ("as [ASN] " + from_str, VTYSH_ROUTER + to_str, help_str), \
               (from_str, VTYSH_ROUTER + to_str, help_str)

    def clear_gen(self, from_str, to_str, help_str):

        return (from_str, to_str + "'", help_str), \
               (from_str + " in", to_str + " in'", help_str), \
               (from_str + " out", to_str + " out'", help_str), \
               (from_str + " soft", to_str + " soft'", help_str), \
               (from_str + " soft in", to_str + " soft in'", help_str), \
               (from_str + " soft out", to_str + " soft out'", help_str)

    def rosetta(self):

        VTYSH = "/usr/bin/vtysh -c "

        base_rosetta = [
            ("version", VTYSH + "'show version'", "show zebra version"),
            ("version show", VTYSH + "'show version'", "show zebra version"),

            ("attribute-info", VTYSH + "'show ip bgp attribute-info'", ""),
            ("attribute-info show", VTYSH + "'show ip bgp attribute-info'", ""),

            ("community-info", VTYSH + "'show ip bgp community-info'", ""),
            ("community-info show", VTYSH + "'show ip bgp community-info'", ""),

            ("dampened-paths", VTYSH + "'show ip bgp dampened-paths'", ""),
            ("dampened-paths show", VTYSH + "'show ip bgp dampened-paths'", ""),

            ("flap-statistics", VTYSH + "'show ip bgp flap-statistics'", ""),
            ("flap-statistics show", VTYSH + "'show ip bgp flap-statistics'", ""),

            ("nexthop", VTYSH + "'show ip bgp nexthop'", ""),
            ("nexthop show", VTYSH + "'show ip bgp nexthop'", ""),
            ("nexthop show detail", VTYSH + "'show ip bgp nexthop detail'", ""),

            # ("update-groups show statistics",
            #  VTYSH + "'show bgp update-groups statistics'", ""),

            ("peer-group", VTYSH + "'show ip bgp peer-group'", ""),
            ("peer-group show", VTYSH + "'show ip bgp peer-group'", ""),

            ("debug set as4", VTYSH + "'debug bgp as4'", ""),
            ("debug clear as4", VTYSH + "'no debug bgp as4'", ""),
            ("debug set as4 segment", VTYSH + "'debug bgp as4 segment'", ""),
            ("debug clear as4 segment", VTYSH + "'no debug bgp as4 segment'", ""),
            ("debug set neighbor-events", VTYSH + "'debug bgp neighbor-events'",
             "debug FSM events associated across all neighbors"),
            ("debug clear neighbor-events", VTYSH + "'no debug bgp neighbor-events'",
             "stop debug FSM events"),
            ("debug set neighbor-events neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
             VTYSH + "'debug bgp neighbor-events /-1'",
             "debug FSM events from a specific neighbor"),
            ("debug clear neighbor-events neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
             VTYSH + "'no debug bgp neighbor-events /-1'",
             "stop debug FSM events from specific neighbor"),
            ("debug set nht", VTYSH + "'debug bgp nht'", ""),
            ("debug clear nht", VTYSH + "'no debug bgp nht'", ""),
            ("debug set keepalives", VTYSH + "'debug bgp keepalives'",
             "debug keepalives from all neighbors"),
            ("debug clear keepalives", VTYSH + "'no debug bgp keepalives'",
             "stop debug keepalives from all neighbors"),
            ("debug set keepalives neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]", VTYSH + "'debug bgp keepalives /-1'",
             "debug keepalives from a specific neighbor"),
            ("debug clear keepalives neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]", VTYSH + "'no debug bgp keepalives /-1'",
             "stop debugging keepalives from specified neighbor"),
            ("debug set updates", VTYSH + "'debug bgp updates'", ""),
            ("debug clear updates", VTYSH + "'no debug bgp updates'", ""),
            ("debug set updates in", VTYSH + "'debug bgp updates in'", ""),
            ("debug set updates in neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]", VTYSH + "'debug bgp updates in /-1'", ""),
            ("debug set updates out", VTYSH + "'debug bgp updates out'", ""),
            ("debug set updates out neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]", VTYSH + "'debug bgp updates out /-1'", ""),
            ("debug clear updates in", VTYSH + "'no debug bgp updates in'", ""),
            ("debug clear updates in neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]", VTYSH + "'no debug bgp updates in /-1'", ""),
            ("debug clear updates out", VTYSH + "'no debug bgp updates out'", ""),
            ("debug clear updates out neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]", VTYSH + "'no debug bgp updates out /-1'", ""),
            ("debug set updates prefix [A.B.C.D/M|X.X::X.X/M]", VTYSH + "'debug bgp updates prefix /-1'",""),
            ("debug clear updates prefix [A.B.C.D/M|X.X::X.X/M]", VTYSH + "'no debug bgp updates prefix /-1'",""),
            ("debug set bestpath prefix [A.B.C.D/M|X.X::X.X/M]", VTYSH + "'debug bgp bestpath /-1'",""),
            ("debug clear bestpath prefix [A.B.C.D/M|X.X::X.X/M]", VTYSH + "'no debug bgp bestpath /-1'",""),
            ("debug set zebra", VTYSH + "'debug bgp zebra'", ""),
            ("debug clear zebra", VTYSH + "'no debug bgp zebra'", ""),
            ("debug set zebra prefix [A.B.C.D/M|X.X::X.X/M]", VTYSH + "'debug bgp zebra prefix /-1'", ""),
            ("debug clear zebra prefix [A.B.C.D/M|X.X::X.X/M]", VTYSH + "'no debug bgp zebra prefix /-1'", ""),
            ("debug set update-groups", VTYSH + "'debug bgp update-groups'", ""),
            ("debug clear update-groups", VTYSH + "'no debug bgp update-groups'", ""),
            ("debug show", VTYSH + "'show debug bgp'", ""),
        ]

        # Multi-protocol rosetta

        mp_rosetta = []
        mp_rosetta += self.mp_gen("neighbor show all",
                                  VTYSH + "'show \a neighbors'", "")
        mp_rosetta += self.mp_gen("neighbor show [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                  VTYSH + "'show \a neighbors /-1'","")

        mp_rosetta += self.mp_gen("neighbor show [A.B.C.D|X.X::X.X|peer-group-name|interface] routes",
                                  VTYSH + "'show \a neighbors /-2 routes'","")
        mp_rosetta += self.mp_gen("neighbor show [A.B.C.D|X.X::X.X|peer-group-name|interface] advertised-routes",
                                  VTYSH + "'show \a neighbors /-2 advertised-routes'","")
        mp_rosetta += self.mp_gen("neighbor show [A.B.C.D|X.X::X.X|peer-group-name|interface] received-routes",
                                  VTYSH + "'show \a neighbors /-2 received-routes'","")
        mp_rosetta += self.mp_gen("neighbor show [A.B.C.D|X.X::X.X|peer-group-name|interface] advertised-routes route-map WORD",
                                  VTYSH + "'show \a neighbors /-4 advertised-routes route-map /-1'","")
        mp_rosetta += self.mp_gen("neighbor show [A.B.C.D|X.X::X.X|peer-group-name|interface] received-routes route-map WORD",
                                  VTYSH + "'show \a neighbors /-4 received-routes route-map /-1'","")

        mp_rosetta += self.mp_gen("paths", VTYSH + "'show \a paths'", "")
        mp_rosetta += self.mp_gen("paths show", VTYSH + "'show \a paths'", "")

        mp_rosetta += self.mp_gen("statistics",
                                  VTYSH + "'show bgp \p unicast statistics'", "")
        mp_rosetta += self.mp_gen("statistics show",
                                  VTYSH + "'show bgp \p unicast statistics'", "")

        mp_rosetta += self.mp_gen("route", VTYSH + "'show \a '", "")
        mp_rosetta += self.mp_gen("route show", VTYSH + "'show \a '", "")
        mp_rosetta += self.mp_gen("route show json", VTYSH + "'show \a json'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M]",
                                  VTYSH + "'show \a /-1'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M] json",
                                  VTYSH + "'show \a /-1 json'", "")
        mp_rosetta += self.mp_gen("route show json", VTYSH + "'show \a json'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M]",
                                  VTYSH + "'show \a /-1'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M] json",
                                  VTYSH + "'show \a /-2 json'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M] bestpath",
                                  VTYSH + "'show \a /-2 bestpath'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M] bestpath json",
                                  VTYSH + "'show \a /-3 bestpath json'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M] multipath",
                                  VTYSH + "'show \a /-2 multipath'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M] multipath json",
                                  VTYSH + "'show \a /-3 multipath json'", "")
        mp_rosetta += self.mp_gen("route show [A.B.C.D/M|X.X::X.X/M] longer-prefixes",
                                  VTYSH + "'show \a /-2 longer-prefixes'", "")
        mp_rosetta += self.mp_gen("route show community",
                                  VTYSH + "'show \a community'", "")
        mp_rosetta += self.mp_gen("route show community [AA:NN]",
                                  VTYSH + "'show \a community /-1'", "")
        mp_rosetta += self.mp_gen("route show filter-list [FILTER]",
                                  VTYSH + "'show \a filter-list /-1'", "")
        mp_rosetta += self.mp_gen("route show prefix-list [PREFIX]",
                                  VTYSH + "'show \a prefix-list /-1'", "")
        mp_rosetta += self.mp_gen("route show regexp [REGEXP]",
                                  VTYSH + "'show \a regexp /-1'",
                                  "show routes with aspath regexp specified. " \
                                  "ASN is always specified with leading '_'. " \
                                  "Example: to show routes originating from " \
                                  "ASN 10, use the command as follows: " \
                                  "cl-bgp route show regexp '_10$'")
        mp_rosetta += self.mp_gen("summary",
                                  VTYSH + "'show \a summary'", "")
        mp_rosetta += self.mp_gen("summary show",
                                  VTYSH + "'show \a summary'", "")
        mp_rosetta += self.mp_gen("summary show json",
                                  VTYSH + "'show \a summary json'", "")
        mp_rosetta += self.mp_gen("update-groups",
                                  VTYSH + "'show \a update-groups'",
                                  "Show detailed info about current dynamic update groups")
        mp_rosetta += self.mp_gen("update-groups show",
                                  VTYSH + "'show \a update-groups'",
                                  "Show detailed info about current dynamic update groups")
        mp_rosetta += self.mp_gen("update-groups show advertise-queue",
                                  VTYSH + "'show \a update-groups advertise-queue'",
                                  "")
        mp_rosetta += self.mp_gen("update-groups show advertise-queue",
                                  VTYSH + "'show \a update-groups advertise-queue'",
                                  "")
        mp_rosetta += self.mp_gen("update-groups show advertised-routes",
                                  VTYSH + "'show \a update-groups advertised-routes'",
                                  "")
        mp_rosetta += self.mp_gen("update-groups show packet-queue",
                                  VTYSH + "'show \a update-groups packet-queue'",
                                  "")
        mp_rosetta += self.mp_gen("update-groups show subgroup <subgroup-ID>",
                                  VTYSH + "'show \a update-groups /-1'",
                                  "Show detailed info about specific dynamic update groups subgroup")
        mp_rosetta += self.mp_gen("update-groups show subgroup <subgroup-ID>",
                                  VTYSH + "'show \a update-groups /-1'",
                                  "Show detailed info about specific dynamic update groups subgroup")
        mp_rosetta += self.mp_gen("update-groups show subgroup <subgroup-ID> advertise-queue",
                                  VTYSH + "'show \a update-groups /-2 advertise-queue'",
                                  "")
        mp_rosetta += self.mp_gen("update-groups show subgroup <subgroup-ID> advertised-routes",
                                  VTYSH + "'show \a update-groups /-2 advertised-routes'",
                                  "")
        mp_rosetta += self.mp_gen("update-groups show subgroup <subgroup-ID> packet-queue",
                                  VTYSH + "'show \a update-groups /-2 packet-queue'",
                                  "")
        
        clear_bgp_rosetta = []
        # Note the missing single quote in the second str below. That is added
        # by clear_gen routine
        clear_bgp_rosetta += self.clear_gen("neighbor restart all",
                                            VTYSH + "'clear ip bgp *", "")
        clear_bgp_rosetta += self.clear_gen("neighbor restart [A.B.C.D|X.X::X.X|peer-group-name|interface] ",
                                            VTYSH + "'clear ip bgp /2", "")
        clear_bgp_rosetta += self.clear_gen("neighbor restart as [ASN] ",
                                            VTYSH + "'clear ip bgp /3 ", "")
        clear_bgp_rosetta += self.clear_gen("neighbor restart external",
                                            VTYSH + "'clear ip bgp external ", "")
        clear_bgp_rosetta += self.clear_gen("neighbor restart peer-group [PEER-GROUP]",
                                            VTYSH + "'clear ip bgp peer-group /3 ", "")

        VTYSH_ROUTER = "/usr/bin/vtysh -c 'conf term' -c 'router bgp /1' -c "

        router_rosetta = []
        router_rosetta += self.as_gen("coalesce-time set <0-4294967295>",
                                      VTYSH_ROUTER + "'coalesce-time /4'",
                                      "Subgroup coalesce timer value (in ms)")
        router_rosetta += self.as_gen("coalesce-time clear <0-4294967295>",
                                      VTYSH_ROUTER + "'no coalesce-time /4'",
                                      "Subgroup coalesce timer value (in ms)")
        router_rosetta += self.as_gen("cluster-id set [A.B.C.D]",
                                      VTYSH_ROUTER + "' bgp cluster-id /4'", "")
        router_rosetta += self.as_gen("cluster-id clear [A.B.C.D]",
                                      VTYSH_ROUTER + "' no bgp cluster-id /4'", "")
        router_rosetta += self.as_gen("cluster-id clear",
                                      VTYSH_ROUTER + "' no bgp cluster-id'", "")
        router_rosetta += self.as_gen("distance set <1-255> [A.B.C.D/M]",
                                      VTYSH_ROUTER + "' distance /4 /5'", "")
        router_rosetta += self.as_gen("distance clear <1-255> [A.B.C.D/M]",
                                      VTYSH_ROUTER + "' no distance /4 /5'", "")
        router_rosetta += self.as_gen("distance set bgp <1-255> <1-255> <1-255>",
                                      VTYSH_ROUTER + "' distance bgp /5 /6 /7'",
                                      "distance for routes external to AS, internal to AS, local routes")
        router_rosetta += self.as_gen("distance clear bgp",
                                      VTYSH_ROUTER + "' no distance bgp'", "")
        router_rosetta += self.as_gen("distance clear bgp <1-255> <1-255> <1-255>",
                                      VTYSH_ROUTER + "' no distance bgp /5 /6 /7'", "")
        router_rosetta += self.as_gen("always-compare-med set",
                                      VTYSH_ROUTER + "'bgp always-compare-med'", "")
        router_rosetta += self.as_gen("always-compare-med clear",
                                      VTYSH_ROUTER + "'no bgp always-compare-med'", "")
        router_rosetta += self.as_gen("default set ipv4-unicast",
                                      VTYSH_ROUTER + "'bgp default ipv4-unicast'", "")
        router_rosetta += self.as_gen("default clear ipv4-unicast",
                                      VTYSH_ROUTER + "'no bgp default ipv4-unicast'", "")
        router_rosetta += self.as_gen("default set show-hostname",
                                      VTYSH_ROUTER + "'bgp default show-hostname'", "")
        router_rosetta += self.as_gen("default clear show-hostname",
                                      VTYSH_ROUTER + "'no bgp default show-hostname'", "")
        router_rosetta += self.as_gen("default set local-preference <0-4294967295>",
                                      VTYSH_ROUTER + "'bgp default local-preference /5'", "")
        router_rosetta += self.as_gen("default clear local-preference",
                                      VTYSH_ROUTER + "'no bgp default local-preference'", "")
        router_rosetta += self.as_gen("default clear local-preference <0-4294967295>",
                                      VTYSH_ROUTER + "'no bgp default local-preference /5'", "")
        router_rosetta += self.as_gen("default set subgroup-pkt-queue-max <20-100>",
                                      VTYSH_ROUTER + "'bgp default subgroup-pkt-queue-max /5'", "")
        router_rosetta += self.as_gen("default clear subgroup-pkt-queue-max",
                                      VTYSH_ROUTER + "'no bgp default subgroup-pkt-queue-max'", "")
        router_rosetta += self.as_gen("enforce-first-as set", VTYSH_ROUTER + "'bgp enforce-first-as'", "")
        router_rosetta += self.as_gen("enforce-first-as clear",
                                      VTYSH_ROUTER + "'no bgp enforce-first-as'", "")
        router_rosetta += self.as_gen("fast-external-failover set",
                                      VTYSH_ROUTER + "'bgp fast-external-failover'", "")
        router_rosetta += self.as_gen("fast-external-failover clear",
                                      VTYSH_ROUTER + "'no bgp fast-external-failover'", "")
        router_rosetta += self.as_gen("import-check set",
                                      VTYSH_ROUTER + "'bgp network import-check'", "")
        router_rosetta += self.as_gen("import-check clear",
                                      VTYSH_ROUTER + "'no bgp network import-check'", "")
        router_rosetta += self.as_gen("import-check set exact",
                                      VTYSH_ROUTER + "'bgp network import-check exact'", "")
        router_rosetta += self.as_gen("import-check clear exact",
                                      VTYSH_ROUTER + "'no bgp network import-check exact'", "")
        router_rosetta += self.as_gen("route-reflector set allow-outbound-policy",
                                      VTYSH_ROUTER + "'bgp route-reflector allow-outbound-policy",
                                      "Allow modifications made by out route-map on route-reflector clients")
        router_rosetta += self.as_gen("route-reflector clear allow-outbound-policy",
                                      VTYSH_ROUTER + "'no bgp route-reflector allow-outbound-policy", "")
        router_rosetta += self.as_gen("listen set range [A.B.C.D/M|X.X::X.X/M] peer-group <WORD>",
                                      VTYSH_ROUTER + "'bgp listen range /5 peer-group /7'",
                                      "Prefix range dynamic neighbors can be from")
        router_rosetta += self.as_gen("listen clear range [A.B.C.D/M|X.X::X.X/M] peer-group <WORD>",
                                      VTYSH_ROUTER + "'no bgp listen range /5 peer-group /7'",
                                      "Disable dynamic neighbor range")
        router_rosetta += self.as_gen("listen set limit <1-5000>",
                                      VTYSH_ROUTER + "'bgp listen limit /5'",
                                      "Limit on number of dynamic peers accepted")
        router_rosetta += self.as_gen("listen clear limit <1-5000>",
                                      VTYSH_ROUTER + "'no bgp listen limit'",
                                      "")
        router_rosetta += self.as_gen("log-neighbor-changes set",
                                      VTYSH_ROUTER + "'bgp log-neighbor-changes'", "")
        router_rosetta += self.as_gen("log-neighbor-changes clear",
                                      VTYSH_ROUTER + "'no bgp log-neighbor-changes'", "")
        router_rosetta += self.as_gen("router-id set [A.B.C.D]",
                                      VTYSH_ROUTER + "'bgp router-id /4'", "")
        router_rosetta += self.as_gen("router-id clear",
                                      VTYSH_ROUTER + "'no bgp router-id'", "")
        router_rosetta += self.as_gen("router-id clear [A.B.C.D]",
                                      VTYSH_ROUTER + "'no bgp router-id /4'", "")
        router_rosetta += self.as_gen("bestpath set as-path multipath-relax",
                                      VTYSH_ROUTER + "'bgp bestpath as-path multipath-relax'", "")
        router_rosetta += self.as_gen("bestpath clear as-path multipath-relax",
                                      VTYSH_ROUTER + "'no bgp bestpath as-path multipath-relax'", "")
        router_rosetta += self.as_gen("bestpath set as-path multipath-relax no-as-set",
                                      VTYSH_ROUTER + "'bgp bestpath as-path multipath-relax no-as-set'", "")
        router_rosetta += self.as_gen("bestpath clear as-path multipath-relax no-as-set",
                                      VTYSH_ROUTER + "'no bgp bestpath as-path multipath-relax no-as-set'", "")
        router_rosetta += self.as_gen("bestpath set as-path ignore",
                                      VTYSH_ROUTER + "'bgp bestpath as-path ignore'", "")
        router_rosetta += self.as_gen("bestpath clear as-path ignore",
                                      VTYSH_ROUTER + "'no bgp bestpath as-path ignore'", "")
        router_rosetta += self.as_gen("bestpath set as-path confed",
                                      VTYSH_ROUTER + "'bgp bestpath as-path confed'", "")
        router_rosetta += self.as_gen("bestpath clear as-path confed",
                                      VTYSH_ROUTER + "'no bgp bestpath as-path confed'", "")
        router_rosetta += self.as_gen("bestpath set compare-routerid",
                                      VTYSH_ROUTER + "'bgp bestpath compare-routerid'", "")
        router_rosetta += self.as_gen("bestpath clear compare-routerid",
                                      VTYSH_ROUTER + "'no bgp bestpath compare-routerid'", "")
        router_rosetta += self.as_gen("bestpath set med confed",
                                      VTYSH_ROUTER + "'bgp bestpath med confed'", "")
        router_rosetta += self.as_gen("bestpath clear med confed",
                                      VTYSH_ROUTER + "'no bgp bestpath med confed'", "")
        router_rosetta += self.as_gen("bestpath set med missing-as-worst",
                                      VTYSH_ROUTER + "'bgp bestpath med missing-as-worst'", "")
        router_rosetta += self.as_gen("bestpath clear med missing-as-worst",
                                      VTYSH_ROUTER + "'no bgp bestpath med missing-as-worst'", "")
        router_rosetta += self.as_gen("bestpath set med missing-as-worst confed",
                                      VTYSH_ROUTER + "'bgp bestpath med missing-as-worst confed'", "")
        router_rosetta += self.as_gen("bestpath clear med missing-as-worst confed",
                                      VTYSH_ROUTER + "'no bgp bestpath med missing-as-worst confed'", "")
        router_rosetta += self.as_gen("deterministic-med set",
                                      VTYSH_ROUTER + "'bgp deterministic-med'", "")
        router_rosetta += self.as_gen("deterministic-med clear",
                                      VTYSH_ROUTER + "'no bgp deterministic-med'", "")
        router_rosetta += self.as_gen("graceful-restart set",
                                      VTYSH_ROUTER + "'bgp graceful-restart'", "")
        router_rosetta += self.as_gen("graceful-restart clear",
                                      VTYSH_ROUTER + "'no bgp graceful-restart'", "")
        router_rosetta += self.as_gen("graceful-restart set stalepath-time <1-3600>",
                                      VTYSH_ROUTER + "'bgp graceful-restart stalepath-time /5'", "")
        router_rosetta += self.as_gen("graceful-restart clear stalepath-time",
                                      VTYSH_ROUTER + "'no bgp graceful-restart stalepath-time'", "")
        router_rosetta += self.as_gen("redistribute add [ROUTETYPE]",
                                      VTYSH_ROUTER + "'redistribute /4'", "")
        router_rosetta += self.as_gen("redistribute del [ROUTETYPE]",
                                      VTYSH_ROUTER + "'no redistribute /4'", "")
        router_rosetta += self.as_gen("solo set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'solo /5'",
                                      "Don't use dynamic update groups on specified peer")
        router_rosetta += self.as_gen("solo clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no solo /5'",
                                      "Don't use dynamic update groups on specified peer")
        router_rosetta += self.as_gen("update-delay set <0-3600>",
                                      VTYSH_ROUTER + "'update-delay /4'", "in secs")
        router_rosetta += self.as_gen("update-delay clear <0-3600>",
                                      VTYSH_ROUTER + "'no update-delay /4'", "in secs")
        router_rosetta += self.as_gen("timers set keepalive <0-65535> holdtime <0-65535>",
                                      VTYSH_ROUTER + "'timers bgp /5 /7'", "")
        router_rosetta += self.as_gen("timers clear keepalive",
                                      VTYSH_ROUTER + "'no timers bgp'", "")
        router_rosetta += self.as_gen("write-quanta set <1-4294967295>",
                                      VTYSH_ROUTER + "'write-quanta /4'",
                                      "Packets to write to peer socket per run")
        router_rosetta += self.as_gen("write-quanta clear",
                                      VTYSH_ROUTER + "'no write-quanta'",
                                      "Revert to 10 packet write to peer socket per run")
        router_rosetta += self.as_gen("table-map set <WORD>",
                                      VTYSH_ROUTER + "'table-map /4'",
                                      "Filter routes sent from BGP to RIB")
        router_rosetta += self.as_gen("table-map clear",
                                      VTYSH_ROUTER + "'no table-map'",
                                      "Stop filtering routes sent from BGP to RIB")
        router_rosetta += self.as_gen("max-med set on-startup time <5-86400> med <1-4294967295>",
                                      VTYSH_ROUTER + "'bgp max-med on-startup /6 /8'",
                                      "Announce routes with maximum med on startup for specified secs")
        router_rosetta += self.as_gen("max-med set administrative",
                                      VTYSH_ROUTER + "'bgp max-med administrative'",
                                      "Announce routes with maximum med")
        router_rosetta += self.as_gen("max-med set administrative time <5-86400>",
                                      VTYSH_ROUTER + "'bgp max-med administrative /6'",
                                      "Announce routes with maximum med for specified secs")
        router_rosetta += self.as_gen("max-med set administrative time <5-86400> med <1-4294967295>",
                                      VTYSH_ROUTER + "'bgp max-med administrative /6 /8'",
                                      "Announce routes with maximum med for specified secs")
        router_rosetta += self.as_gen("max-med clear on-startup",
                                      VTYSH_ROUTER + "'no bgp max-med on-startup'",
                                      "Stop announcing routes with maximum med on startup")
        router_rosetta += self.as_gen("max-med clear administrative",
                                      VTYSH_ROUTER + "'no bgp max-med administrative'",
                                      "Stop announcing routes with maximum med")
        router_rosetta += self.as_gen("route-map-delay-timer set <0-600>",
                                      VTYSH_ROUTER + "'bgp route-map delay-timer /4'",
                                      "Time in secs to wait before applying route-map changes")
        router_rosetta += self.as_gen("route-map-delay-timer clear",
                                      VTYSH_ROUTER + "'no bgp route-map delay-timer'",
                                      "Revert to default time to wait to react to routemap changes")


        # More complicated router commands
        router_rosetta += self.as_gen("peer-group add [NAME]",
                                      VTYSH_ROUTER + "'neighbor /4 peer-group'", "")
        router_rosetta += self.as_gen("peer-group del [NAME]",
                                      VTYSH_ROUTER + "'no neighbor /4 peer-group'", "")
        router_rosetta += self.as_gen("interface add [NAME]",
                                      VTYSH_ROUTER + "'neighbor /4 interface'",
                                      "Signal intention to use interface specified as neighbor")
        router_rosetta += self.as_gen("interface del [NAME]",
                                      VTYSH_ROUTER + "'no neighbor /4 interface'",
                                      "Stop using interface specified as neighbor")
        router_rosetta += self.as_gen("neighbor add [A.B.C.D|X.X::X.X|peer-group-name|interface] remote-as [ASN|internal|external]",
                                      VTYSH_ROUTER + "'neighbor /4 remote-as /6'", "")
        router_rosetta += self.as_gen("neighbor del [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /4'", "")
        router_rosetta += self.as_gen("neighbor del [A.B.C.D|X.X::X.X|peer-group-name|interface] remote-as [ASN|internal|external]",
                                      VTYSH_ROUTER + "'no neighbor /4 remote-as /6'", "")
        router_rosetta += self.as_gen("neighbor set [A.B.C.D|X.X::X.X|peer-group-name|interface] interface [INTERFACE]",
                                      VTYSH_ROUTER + "'neighbor /4 interface /6'", "")
        router_rosetta += self.as_gen("neighbor clear [A.B.C.D|X.X::X.X|peer-group-name|interface] interface [INTERFACE]",
                                      VTYSH_ROUTER + "'no neighbor /4 interface /6'", "")
        router_rosetta += self.as_gen("neighbor stop [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /4 shutdown'", "")
        router_rosetta += self.as_gen("neighbor start [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /4 shutdown'", "")
        router_rosetta += self.as_gen("ttl-security set hops <1-254> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /7 ttl-security hops /5'", "")
        router_rosetta += self.as_gen("ttl-security clear hops <1-254> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /7 ttl-security hops /5'", "")
        router_rosetta += self.as_gen("disable-connected-check set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /5 disable-connected-check'", "")
        router_rosetta += self.as_gen("disable-connected-check clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /5 disable-connected-check'", "")
        router_rosetta += self.as_gen("ebgp-multihop set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /5 ebgp-multihop'", "")
        router_rosetta += self.as_gen("ebgp-multihop clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /5 ebgp-multihop'", "")
        router_rosetta += self.as_gen("ebgp-multihop set hops <1-255> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /7 ebgp-multihop /5'", "")
        router_rosetta += self.as_gen("ebgp-multihop clear hops <1-255> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /7 ebgp-multihop /5'", "")
        router_rosetta += self.as_gen("passive set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /5 passive'", "")
        router_rosetta += self.as_gen("passive clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /5 passive'", "")
        router_rosetta += self.as_gen("local-as set [ASN] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /6 local-as /4'", "")
        router_rosetta += self.as_gen("local-as clear [ASN] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /6 local-as /4'", "")
        router_rosetta += self.as_gen("local-as set [ASN] no-prepend neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /7 local-as /4 no-prepend'", "")
        router_rosetta += self.as_gen("local-as clear [ASN] no-prepend neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /7 local-as /4 no-prepend'", "")
        router_rosetta += self.as_gen("local-as set [ASN] no-prepend replace-as neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /8 local-as /4 no-prepend replace-as'", "")
        router_rosetta += self.as_gen("local-as clear [ASN] no-prepend replace-as neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /8 local-as /4 no-prepend replace-as'", "")
        router_rosetta += self.as_gen("timers set keepalive <0-65535> holdtime <0-65535> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /9 timers /5 /7'", "")
        router_rosetta += self.as_gen("timers clear keepalive neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /6 timers'", "")
        router_rosetta += self.as_gen("timers set connect <0-65535> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /7 timers connect /5'", "")
        router_rosetta += self.as_gen("timers clear connect <0-65535> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /7 timers connect /5'", "")
        router_rosetta += self.as_gen("update-source set [A.B.C.D|X.X::X.X] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /6 update-source /4'", "")
        router_rosetta += self.as_gen("update-source clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /5 update-source'", "")
        router_rosetta += self.as_gen("update-source set interface [INTERFACE] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /7 update-source /5'", "")
        router_rosetta += self.as_gen("update-source clear interface [INTERFACE] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /7 update-source'", "")
        router_rosetta += self.as_gen("weight set <0-65535> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /6 weight /4'", "")
        router_rosetta += self.as_gen("weight clear <0-65535> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /6 weight /4'", "")
        router_rosetta += self.as_gen("advertisement-interval set <0-600> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /6 advertisement-interval /4'", "")
        router_rosetta += self.as_gen("advertisement-interval clear <0-600> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /6 advertisement-interval /4'", "")
        router_rosetta += self.as_gen("description set [STRING] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /6 description /4'", "Upto 80 chars")
        router_rosetta += self.as_gen("description clear [STRING] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /6 description /4'", "Upto 80 chars")
        router_rosetta += self.as_gen("capability set [WORD] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /6 capability /4'", "")
        router_rosetta += self.as_gen("capability clear [WORD] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /6 capability /4'", "")
        router_rosetta += self.as_gen("capability set orf prefix-list [WORD] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /8 capability orf prefix-list /6'", "")
        router_rosetta += self.as_gen("capability clear orf prefix-list [WORD] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /8 capability orf prefix-list /6'", "")
        router_rosetta += self.as_gen("attribute-unchanged set [WORD] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /6 attribute-unchanged /4'",
                                      "Propagate specified attribute unchanged")
        router_rosetta += self.as_gen("attribute-unchanged clear [WORD] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /6 attribute-unchanged /4'",
                                      "Stop propagating the attribute unchanged")
        router_rosetta += self.as_gen("dampen set half-life <1-45> reuse-time <1-20000> suppress-time <1-20000> max-stable <1-255>",
                                      VTYSH_ROUTER + "'bgp dampening /5 /7 /9 /-1'", "")
        router_rosetta += self.as_gen("dampen clear half-life <1-45> reuse-time <1-20000> suppress-time <1-20000> max-stable <1-255>",
                                      VTYSH_ROUTER + "'no bgp dampening /5 /7 /9 /-1'", "")
        router_rosetta += self.as_gen("bfd set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /5 bfd'", "Enable BFD")
        router_rosetta += self.as_gen("bfd set detect-multiplier <2-255> min-rx <50-60000> min-tx <50-60000> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'neighbor /-1 bfd /5 /7 /9'", "Enable BFD")
        router_rosetta += self.as_gen("bfd clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      VTYSH_ROUTER + "'no neighbor /5 bfd'", "Disable BFD")
        # Address family-specific Rosetta

        router_afi_rosetta = []
        router_afi_rosetta += self.afi_gen("neighbor activate [A.B.C.D|X:X::X:X|peer-group-name|interface]",
                                           "'neighbor /4 activate'", "")
        router_afi_rosetta += self.afi_gen("neighbor deactivate [A.B.C.D|X:X::X:X|peer-group-name|interface]",
                                           "'no neighbor /4 activate'", "")
        router_afi_rosetta += self.afi_gen("maximum-paths set <1-255>",
                                           "'maximum-paths /4'", "")
        router_afi_rosetta += self.afi_gen("maximum-paths clear <1-255>",
                                           "'no maximum-paths /4'", "")
        router_afi_rosetta += self.afi_gen("maximum-paths-ibgp set <1-255>",
                                           "'maximum-paths ibgp /4'", "")
        router_afi_rosetta += self.afi_gen("maximum-paths-ibgp clear <1-255>",
                                           "'no maximum-paths ibgp /4'", "")
        router_afi_rosetta += self.afi_gen("maximum-paths-ibgp set <1-255> equal-cluster-length",
                                           "'maximum-paths ibgp /4 /5'", "")
        router_afi_rosetta += self.afi_gen("maximum-paths-ibgp clear <1-255> equal-cluster-length",
                                           "'no maximum-paths ibgp /4 /5'", "")
        router_afi_rosetta += self.afi_gen("network add [A.B.C.D/M|X.X::X.X/M]",
                                           "'network /4'", "")
        router_afi_rosetta += self.afi_gen("network del [A.B.C.D/M|X.X::X.X/M]",
                                           "'no network /4'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address add [A.B.C.D/M|X.X::X.X/M] as-set",
                                           "'aggregate-address /4 as-set'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address add [A.B.C.D/M|X.X::X.X/M] summary-only",
                                           "'aggregate-address /4 summary-only'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address add [A.B.C.D/M|X.X::X.X/M] as-set summary-only",
                                           "'aggregate-address /4 as-set summary-only'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address add [A.B.C.D/M|X.X::X.X/M] summary-only as-set",
                                           "'aggregate-address /4 summary-only as-set'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address add [A.B.C.D/M|X.X::X.X/M]",
                                           "'aggregate-address /4'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address del [A.B.C.D/M|X.X::X.X/M]",
                                           "'no aggregate-address /4'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address del [A.B.C.D/M|X.X::X.X/M] as-set",
                                           "'no aggregate-address /4 as-set'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address del [A.B.C.D/M|X.X::X.X/M] summary-only",
                                           "'no aggregate-address /4 summary-only'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address del [A.B.C.D/M|X.X::X.X/M] as-set summary-only",
                                           "'no aggregate-address /4 as-set summary-only'", "")
        router_afi_rosetta += self.afi_gen("aggregate-address del [A.B.C.D/M|X.X::X.X/M] summary-only as-set",
                                           "'no aggregate-address /4 summary-only as-set'", "")
        router_rosetta += self.afi_gen("as-override set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      "neighbor /5 as-override", "")
        router_rosetta += self.afi_gen("as-override clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                      "no neighbor /5 as-override", "")
        router_rosetta += self.afi_gen("neighbor add [A.B.C.D|X.X::X.X|peer-group-name|interface] peer-group [WORD]",
                                      "'neighbor /4 peer-group /-1'", "")
        router_rosetta += self.afi_gen("neighbor del [A.B.C.D|X.X::X.X|peer-group-name|interface] peer-group [WORD]",
                                      "'no neighbor /4 peer-group /-1'", "")
        router_rosetta += self.afi_gen("next-hop-self set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                       "'neighbor /5 next-hop-self'", "")
        router_rosetta += self.afi_gen("next-hop-self clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /5 next-hop-self'", "")
        router_rosetta += self.afi_gen("allowas-in set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /5 allowas-in'", "")
        router_rosetta += self.afi_gen("allowas-in clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /5 allowas-in'", "")
        router_rosetta += self.afi_gen("maximum-prefix set <1-4294967295> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /6 maximum-prefix /4'", "")
        router_rosetta += self.afi_gen("maximum-prefix clear <1-4294967295> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /6 maximum-prefix /4'", "")
        router_rosetta += self.afi_gen("maximum-prefix set <1-4294967295> threshold <1-100%> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /8 maximum-prefix /4 /6'",
                                       "threshold at which to generate warning message")
        router_rosetta += self.afi_gen("maximum-prefix set <1-4294967295> restart <1-65535> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /8 maximum-prefix /4 restart /6'", "")
        router_rosetta += self.afi_gen("maximum-prefix clear <1-4294967295> restart <1-65535> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /8 maximum-prefix /4 restart /6'", "")
        router_rosetta += self.afi_gen("maximum-prefix set <1-4294967295> warning-only neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 maximum-prefix /4 warning-only'", "")
        router_rosetta += self.afi_gen("default-originate set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /5 default-originate'", "")
        router_rosetta += self.afi_gen("default-originate set route-map [RMAP-NAME] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 default-originate route-map /5'", "")
        router_rosetta += self.afi_gen("default-originate clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /5 default-originate'", "")
        router_rosetta += self.afi_gen("default-originate clear route-map [RMAP-NAME] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /7 default-originate route-map /5'", "")
        router_rosetta += self.afi_gen("route-map set [ROUTEMAP] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /6 route-map /4'", "")
        router_rosetta += self.afi_gen("route-map clear [ROUTEMAP] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /6 route-map /4'", "")
        router_rosetta += self.afi_gen("route-map set [ROUTEMAP] [in|out|import|export] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 route-map /4 /5'", "")
        router_rosetta += self.afi_gen("route-map clear [ROUTEMAP] [in|out|import|export] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /7 route-map /4 /5'", "")
        router_rosetta += self.afi_gen("route-reflector-client set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface] ",
                                        "'neighbor /5 route-reflector-client'", "")
        router_rosetta += self.afi_gen("route-reflector-client clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /5 route-reflector-client'", "")
        router_rosetta += self.afi_gen("route-server-client set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface] ",
                                        "'neighbor /5 route-server-client'", "")
        router_rosetta += self.afi_gen("route-server-client clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /5 route-server-client'", "")
        router_rosetta += self.afi_gen("remove-private-as set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /5 remove-private-AS'", "")
        router_rosetta += self.afi_gen("remove-private-as clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /5 remove-private-AS'", "")
        router_rosetta += self.afi_gen("prefix-list set [WORD] in neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 prefix-list /4 in'", "")
        router_rosetta += self.afi_gen("prefix-list clear [WORD] in neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /7 prefix-list /4 in'", "")
        router_rosetta += self.afi_gen("prefix-list set [WORD] out neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 prefix-list /4 out'", "")
        router_rosetta += self.afi_gen("prefix-list clear [WORD] out neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /7 prefix-list /4 out'", "")
        router_rosetta += self.afi_gen("distribute-list set [WORD] in neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 distribute-list /4 in'", "")
        router_rosetta += self.afi_gen("distribute-list clear [WORD] in neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /7 distribute-list /4 in'", "")
        router_rosetta += self.afi_gen("distribute-list set [WORD] out neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 distribute-list /4 out'", "")
        router_rosetta += self.afi_gen("distribute-list clear [WORD] neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /7 distribute-list /4'", "")
        router_rosetta += self.afi_gen("filter-list set [WORD] in neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 filter-list /4 in'", "")
        router_rosetta += self.afi_gen("filter-list clear [WORD] in neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /7 filter-list /4 in'", "")
        router_rosetta += self.afi_gen("filter-list set [WORD] out neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /7 filter-list /4 out'", "")
        router_rosetta += self.afi_gen("filter-list clear [WORD] out neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /7 filter-list /4 out'", "")

        router_rosetta += self.afi_gen("send-community set both neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /6 send-community both'", "")
        router_rosetta += self.afi_gen("send-community clear both neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /6 send-community both'", "")
        router_rosetta += self.afi_gen("send-community set standard neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /6 send-community standard'", "")
        router_rosetta += self.afi_gen("send-community clear standard neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /6 send-community standard'", "")
        router_rosetta += self.afi_gen("send-community extended set neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /6 send-community extended'", "")
        router_rosetta += self.afi_gen("send-community extended clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /6 send-community extended'", "")

        router_rosetta += self.afi_gen("soft-reconfiguration set inbound neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /6 soft-reconfiguration inbound'", "")
        router_rosetta += self.afi_gen("soft-reconfiguration clear inbound neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /6 soft-reconfiguration inbound'", "")
        router_rosetta += self.afi_gen("unsuppress-map set <WORD> neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'neighbor /6 unsuppress-map /4'",
                                       "Apply unsuppress-map on routes announced to neighbor")
        router_rosetta += self.afi_gen("unsuppress-map clear neighbor [A.B.C.D|X.X::X.X|peer-group-name|interface]",
                                        "'no neighbor /5 unsuppress-map foo'",
                                       "Don't apply unsuppress-map on routes announced to neighbor")


        return ClCmdHandler.rosetta(self) + base_rosetta + clear_bgp_rosetta + mp_rosetta + router_rosetta + router_afi_rosetta

    def completers(self):
        bgp_completers = {
            "-6 neighbor show": self.complete_neighbor_v6,
            "-4 neighbor show": self.complete_neighbor_v4,
            "neighbor show": self.complete_neighbor_v4,
            "neighbor del": self.complete_neighbor,
            "neighbor restart": self.complete_neighbor,
            "neighbor set": self.complete_neighbor,
            "neighbor clear": self.complete_neighbor,
            "neighbor activate": self.complete_neighbor,
            "neighbor deactivate": self.complete_neighbor,
            "neighbor start": self.complete_neighbor,
            "neighbor stop": self.complete_neighbor,
            "* neighbor": self.complete_neighbor,
            "redistribute add": self.complete_redistribute,
            "redistribute del": self.complete_redistribute,
            "* interface": self.complete_interface,
            "router-id set": self.complete_router_id,
            "router-id clear": self.complete_router_id,
            " as " : self.complete_asn,
            "capability set" : self.complete_capability,
            "capability clear" : self.complete_capability,
            "attribute-unchanged set" : self.complete_attr_unchanged,
            "attribute-unchanged clear" : self.complete_attr_unchanged,
            "* orf": self.complete_orf,
            }
        return dict(ClCmdHandler.completers(self).items() + bgp_completers.items())

    def complete_neighbor_v6(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ipv6 bgp summary'|" \
                            "/bin/grep '^[a-f0-9s]'| /usr/bin/cut -f1 -d ' '", shell=True)

        return out.split()

    def complete_neighbor_v4(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show ip bgp summary'|" \
                            "/bin/grep '^[a-f0-9s]'| /usr/bin/cut -f1 -d ' '", shell=True)

        return out.split()

    def complete_neighbor(self, args):
        if len(args) == 1:
            return ["show", "add", "del", "clear", "set", "start", "stop", "activate", "deactivate"]

        out, err = self.run("/usr/bin/vtysh -c 'show ip bgp summary'|" \
                            "/bin/grep '^[a-f0-9s]'| /usr/bin/cut -f1 -d ' '", shell=True)
        out1, err = self.run("/usr/bin/vtysh -c 'show ipv6 bgp summary'|" \
                            "/bin/grep '^[a-f0-9s]'| /usr/bin/cut -f1 -d ' '", shell=True)

        out += out1

        return out.split()

    def complete_redistribute(self, args):
        return ["kernel", "connected", "static", "rip", "isis", "ospf", "babel", "ospf6"]

    def complete_interface(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show interface'|" \
                            "/bin/grep '^Interface'| /usr/bin/cut -f2 -d ' '", shell=True)
        return out.split()

    def complete_asn(self, args):
        out4, err = self.run("/usr/bin/vtysh -c 'show ip bgp summary'|" \
                            "/bin/grep '^[a-f0-9s]'| /usr/bin/cut -f3 -d ' '", shell=True)
        out6, err = self.run("/usr/bin/vtysh -c 'show ipv6 bgp summary'|" \
                            "/bin/grep '^[a-f0-9s]'| /usr/bin/cut -f3 -d ' '", shell=True)

        if self.mode is "4":
            out = out4
        elif self.mode is "6":
            out = out6
        else:
            out = out4 + out6

        return out.split()

    def complete_router_id(self, args):
        out, err = self.run("/usr/bin/vtysh -c 'show running-config'|" \
                            "/bin/grep 'bgp router-id' | /usr/bin/awk '{print $3}'", shell=True)
        return out.split()

    def complete_capability(self, args):
        return ["dynamic", "extended-nexthop"]

    def complete_orf(self, args):
        return ["both", "send", "receive"]

    def complete_attr_unchanged(self, args):
        return ["as-path", "med", "next-hop"]
