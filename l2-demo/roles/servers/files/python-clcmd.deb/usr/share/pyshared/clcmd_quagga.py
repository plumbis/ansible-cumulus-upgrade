#!/usr/bin/env python

from clcmd_handler import ClCmdHandler

class ClCmdQuagga(ClCmdHandler):

    def rosetta(self):

        VTYSH = "/usr/bin/vtysh -c "

        quagga_rosetta = [
            ("memory", VTYSH + "'show memory'", "show memory statistics"),
            ("memory show", VTYSH + "'show memory'", "show memory statistics"),
            ("logging", VTYSH + "'show logging'", "show current logging configuration"),
            ("logging show", VTYSH + "'show logging'", "show current logging configuration"),
            ("version", VTYSH + "'show version'", "show zebra version"),
            ("version show", VTYSH + "'show version'", "show zebra version"),
            ("table", VTYSH + "'show table'", "show default kernel routing table to use"),
            ("table show", VTYSH + "'show table'", "show default kernel routing table to use"),
            ("startup-config", VTYSH + "'show startup-config'", "show contents of startup configuration"),
            ("startup-config show", VTYSH + "'show startup-config'", "show contents of startup configuration"),
            ("running-config", VTYSH + "'show running-config'", "show current operating configuration"),
            ("running-config show", VTYSH + "'show running-config'", "show current operating configuration"),
            ("debug show zebra", VTYSH + "'show debugging zebra'", "show zebra debug status"),
            ("debug set zebra [OBJECT]", VTYSH + "'debug /2 /3'", "enable zebra debug for OBJECT := { %s }" % ' | '.join(self.debug_zebra_objects(None))),
            ("debug clear zebra [OBJECT]", VTYSH + "'no debug /2 /3'", "disable zebra debug for OBJECT := { %s }" % ' | '.join(self.debug_zebra_objects(None))),
            ("debug set zebra all", self.debug_set_zebra_all, "enable zebra debug for all objects"),
            ("debug clear zebra all", self.debug_clear_zebra_all, "disable zebra debug for all objects"),
        ]

        VTYSH_TERM = "/usr/bin/vtysh -c 'conf term' -c "

        term_rosetta = [
            ("write-config",
             VTYSH_TERM + "'do write file'",
             "Write config to individual protocol files"),
            ("write-config integrated",
             VTYSH_TERM + "'service integrated-vtysh-config'" + " -c 'do write file'",
             "Write config to a single config file"),
            ("running-config copy startup-config",
             VTYSH + "'copy running-config startup-config'",
             "copy operating configuration to startup configuration"),
            ("running-config copy startup-config integrated",
             VTYSH_TERM + "'service integrated-vtysh-config'"  + " -c 'do copy running-config startup-config'",
             "copy operating configuration to startup configuration"),
            ]

        return ClCmdHandler.rosetta(self) + quagga_rosetta + term_rosetta

    def completers(self):
       quagga_completers = {
           "debug set zebra": self.debug_zebra_objects,
           "debug clear zebra": self.debug_zebra_objects,
       }
       return dict(ClCmdHandler.completers(self).items() + quagga_completers.items())

    def debug_zebra_objects(self, args):
        return ["events", "kernel", "packet", "rib", "rib-queue", "nht", "fpm"]

    def debug_set_zebra_all(self, args):
        for obj in self.debug_zebra_objects(args):
            out, err = self.run("/usr/bin/vtysh -c 'debug zebra %s'" % obj)
        return ""

    def debug_clear_zebra_all(self, args):
        for obj in self.debug_zebra_objects(args):
            out, err = self.run("/usr/bin/vtysh -c 'no debug zebra %s'" % obj)
        return ""
